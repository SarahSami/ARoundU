package com.app;


public final class CommonUtilities {

public static final String SENDER_ID = "123485753641";//id project 

}